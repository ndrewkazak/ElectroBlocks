import{g as s,s as t,G as a,a as n}from"./index-454a0f5f.DKKA-n_3.js";import"./alerts.DcEBuQUd.js";const e=async()=>{const o=s();t(o,new a)},r=async()=>{const o=s();await n(o)};export{r as a,e as l};
