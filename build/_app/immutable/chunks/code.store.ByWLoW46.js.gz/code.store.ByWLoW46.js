import{w as r}from"./index.B_SVVHSE.js";import{M as s}from"./microcontroller.BVjUfh2V.js";const o=`int simple_loop_variable = 0;
struct RGB {
	int red;
	int green;
	int blue;
};




void setup() {

}


void loop() {

}
`,e=r({code:o,boardType:s.ARDUINO_UNO}),d={set:e.set,subscribe:e.subscribe,resetCode:t=>e.set({code:o,boardType:t})};export{d as c};
