import{w as e}from"./index.B_SVVHSE.js";const s=e(!1),o={subscribe:s.subscribe,set:s.set,update:s.update};export{o as s};
