var A=(a=>(a.ARDUINO_UNO="uno",a.ARDUINO_MEGA="mega",a))(A||{});export{A as M};
