function i(e){return new Promise(t=>setTimeout(t,e))}export{i as w};
