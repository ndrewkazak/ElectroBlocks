import{s as h,n as l}from"../chunks/scheduler.ydM6q-DU.js";import{S as r,i as g,s as p,e as u,h as d,d as o,a as f,c as j,g as m,f as v,b as i}from"../chunks/index.DrhsS78m.js";function w(c){let t,e,n=`<div class="col"><h2 class="svelte-jisjgq">Getting Help</h2> <p>The fastest way to get help is join our
      <a href="https://discord.gg/8fq8Dj5BtA" class="svelte-jisjgq">discord</a>
      channel. Post any related question you have there and we&#39;ll be happy to
      answer them.</p> <h2 class="svelte-jisjgq">Lessons &amp; Docs</h2> <p>There is also an
      <a href="https://electroblocks.github.io/docs/" class="svelte-jisjgq">ElectroBlock Docs</a>,
      which contains all the lessons in webpage form. We also have a page full
      of
      <a href="/lessons" class="svelte-jisjgq">lessons</a>
      as well.</p> <h2 class="svelte-jisjgq">Training</h2> <p>All training will be scheduled ElectroBlock&#39;s
      <a href="https://www.downtomeet.com/ElectroBlocks/events" class="svelte-jisjgq">Down to Meet.</a>
      We&#39;ll be using either zoom or google hangouts. Anything you want to be
      trained on please let us know. :)</p> <h2 class="svelte-jisjgq">Filling Bugs</h2> <p>If you want to file a bug you can use the built
      <a href="/settings/bugs" class="svelte-jisjgq">bug form</a>
      or
      <a href="https://github.com/phptuts/ElectroBlocksV3/issues" class="svelte-jisjgq">Github Issues</a>.</p></div>`;return{c(){t=p(),e=u("div"),e.innerHTML=n,this.h()},l(s){d("svelte-4tybqj",document.head).forEach(o),t=f(s),e=j(s,"DIV",{class:!0,"data-svelte-h":!0}),m(e)!=="svelte-k7qg1l"&&(e.innerHTML=n),this.h()},h(){document.title="ElectroBlocks - Support",v(e,"class","row")},m(s,a){i(s,t,a),i(s,e,a)},p:l,i:l,o:l,d(s){s&&(o(t),o(e))}}}class _ extends r{constructor(t){super(),g(this,t,null,w,h,{})}}export{_ as component};
